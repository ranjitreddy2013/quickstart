"""HPE DI custom-function API; French OCR and recursive document text extraction."""
import ipaddress
import json
import os
import socket
import tempfile
import threading
import time
from email import policy
from email.parser import BytesParser
from io import BytesIO
from pathlib import Path
from urllib.parse import urlparse

import fitz
import openpyxl
import requests
import xlrd
import extract_msg
from fastapi import FastAPI, HTTPException
from paddleocr import PaddleOCR
from pydantic import BaseModel

from entity_extractor import extract_entities

app = FastAPI(title='PaddleOCR French Multi-format Custom Function', version='3.0')
lock = threading.Lock()
ocr = PaddleOCR(lang='fr', ocr_version='PP-OCRv5', enable_mkldnn=False,
                device='cpu', use_doc_orientation_classify=False,
                use_doc_unwarping=False, use_textline_orientation=False)

MAX_BYTES = int(os.getenv('MAX_BYTES', str(50 * 1024 * 1024)))
MAX_ATTACHMENT_BYTES = int(os.getenv('MAX_ATTACHMENT_BYTES', str(15 * 1024 * 1024)))
MAX_TOTAL_ATTACHMENT_BYTES = int(os.getenv('MAX_TOTAL_ATTACHMENT_BYTES', str(50 * 1024 * 1024)))
MAX_DEPTH = int(os.getenv('MAX_DEPTH', '3'))
MAX_ATTACHMENTS = int(os.getenv('MAX_ATTACHMENTS', '40'))
MAX_PDF_PAGES = int(os.getenv('MAX_PDF_PAGES', '50'))
MAX_PDF_PIXELS = int(os.getenv('MAX_PDF_PIXELS', '12000000'))
MAX_SHEETS = int(os.getenv('MAX_SHEETS', '30'))
MAX_CELLS = int(os.getenv('MAX_CELLS', '200000'))
MAX_TEXT_CHARS = int(os.getenv('MAX_TEXT_CHARS', '500000'))
ALLOWED_HOSTS = {h.strip().lower() for h in os.getenv('ALLOWED_S3_HOSTS', '').split(',') if h.strip()}
SUFFIXES = {'.jpg', '.jpeg', '.png', '.pdf', '.eml', '.msg', '.xls', '.xlsx'}

class ProcessRequest(BaseModel):
    url: str
    objectKey: str
    bucketName: str
    collectionName: str
    versionId: str = ''

class InvalidDocument(Exception):
    pass

class TemporaryFailure(Exception):
    pass

@app.get('/health')
def health():
    return {'status': 'ok', 'model': 'paddleocr-fr-v3'}

def suffix_of(name):
    suffix = Path(name.lower()).suffix
    if suffix not in SUFFIXES:
        raise InvalidDocument(f'Unsupported document type: {suffix or "none"}')
    return suffix

def download(url):
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise InvalidDocument('Invalid object URL')
    host = parsed.hostname.lower().rstrip('.')
    if not ALLOWED_HOSTS or host not in ALLOWED_HOSTS:
        raise InvalidDocument('S3 hostname not on allowlist')
    # Defend against a hostname that resolves to unexpected addresses. In
    # production also enforce egress policy and restrict access to S3 endpoints.
    try:
        resolved = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == 'https' else 80))
    except OSError:
        raise TemporaryFailure('S3 hostname resolution failed')
    if not resolved:
        raise TemporaryFailure('S3 hostname resolution returned no addresses')
    try:
        with requests.get(url, stream=True, timeout=(10, 120), allow_redirects=False, proxies={'http': None, 'https': None}) as response:
            if 300 <= response.status_code < 400:
                raise InvalidDocument('S3 URL redirects are not permitted')
            if response.status_code >= 500 or response.status_code in (408, 429):
                raise TemporaryFailure('S3 temporarily unavailable')
            if response.status_code >= 400:
                raise InvalidDocument('Cannot read source object')
            content_length = response.headers.get('Content-Length')
            if content_length and int(content_length) > MAX_BYTES:
                raise InvalidDocument('Source object exceeds size limit')
            buf = bytearray()
            for chunk in response.iter_content(65536):
                buf.extend(chunk)
                if len(buf) > MAX_BYTES:
                    raise InvalidDocument('Source object exceeds size limit')
            return bytes(buf)
    except requests.RequestException as exc:
        raise TemporaryFailure('S3 download failure') from exc

def new_result():
    return {'sections': [], 'scores': [], 'detections': [], 'warnings': [],
            'attachment_count': 0, 'page_count': 0, 'sheet_count': 0,
            'ocr_used': False, 'total_attachment_bytes': 0, 'cell_count': 0}

def append_text(ctx, origin, text):
    if text and text.strip():
        ctx['sections'].append((origin, text.strip()))

def image_ocr(data, suffix, origin, ctx):
    # Preserve the working PaddleOCR inference/result-parsing path.
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(data)
        path = tmp.name
    try:
        with lock:
            results = ocr.predict(path)
        ctx['ocr_used'] = True
        lines = []
        for result in results:
            info = result.json
            info = info.get('res', info)
            texts = info.get('rec_texts', [])
            scores = info.get('rec_scores', [])
            boxes = info.get('rec_polys', [])
            for i, line in enumerate(texts):
                score = float(scores[i]) if i < len(scores) else 0.0
                poly = boxes[i] if i < len(boxes) else []
                poly = poly.tolist() if hasattr(poly, 'tolist') else poly
                lines.append(str(line))
                ctx['scores'].append(score)
                ctx['detections'].append({'source': origin, 'text': str(line),
                                          'confidence': score, 'polygon': poly})
        append_text(ctx, origin, '\n'.join(lines))
    finally:
        Path(path).unlink(missing_ok=True)

def pdf_extract(data, origin, ctx):
    try:
        doc = fitz.open(stream=data, filetype='pdf')
        if doc.needs_pass:
            raise InvalidDocument('Password-protected PDF is unsupported')
        if doc.page_count > MAX_PDF_PAGES:
            raise InvalidDocument('PDF exceeds page limit')
        ctx['page_count'] += doc.page_count
        for index, page in enumerate(doc):
            label = f'{origin} / page {index + 1}'
            text = page.get_text('text', sort=True).strip()
            if len(text) >= 30:
                append_text(ctx, label, text)
                continue
            # Scanned or nearly empty page: rasterize and OCR.
            zoom = 2.0
            if page.rect.width * page.rect.height * zoom * zoom > MAX_PDF_PIXELS:
                raise InvalidDocument('PDF page exceeds rasterization pixel limit')
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            image_ocr(pix.tobytes('png'), '.png', label, ctx)
        doc.close()
    except (fitz.FileDataError, fitz.EmptyFileError) as exc:
        raise InvalidDocument('Invalid PDF') from exc

def excel_extract(data, suffix, origin, ctx):
    if suffix == '.xlsx':
        try:
            wb = openpyxl.load_workbook(BytesIO(data), read_only=True, data_only=True,
                                        keep_links=False)
            if len(wb.sheetnames) > MAX_SHEETS:
                raise InvalidDocument('Workbook exceeds sheet limit')
            for sheet in wb:
                ctx['sheet_count'] += 1
                rows = []
                for row in sheet.iter_rows(values_only=True):
                    ctx['cell_count'] += len(row)
                    if ctx['cell_count'] > MAX_CELLS:
                        raise InvalidDocument('Workbook exceeds cell limit')
                    values = [str(v).replace('\n', ' ') if v is not None else '' for v in row]
                    if any(values):
                        rows.append(' | '.join(values))
                append_text(ctx, f'{origin} / sheet {sheet.title}', '\n'.join(rows))
            wb.close()
        except (ValueError, KeyError, OSError, TypeError) as exc:
            raise InvalidDocument('Invalid XLSX workbook') from exc
    else:
        try:
            wb = xlrd.open_workbook(file_contents=data, on_demand=True)
            if wb.nsheets > MAX_SHEETS:
                raise InvalidDocument('Workbook exceeds sheet limit')
            for sheet in wb.sheets():
                ctx['sheet_count'] += 1
                rows = []
                for r in range(sheet.nrows):
                    ctx['cell_count'] += sheet.ncols
                    if ctx['cell_count'] > MAX_CELLS:
                        raise InvalidDocument('Workbook exceeds cell limit')
                    vals = [str(v) if v != '' else '' for v in sheet.row_values(r)]
                    if any(vals):
                        rows.append(' | '.join(vals))
                append_text(ctx, f'{origin} / sheet {sheet.name}', '\n'.join(rows))
            wb.release_resources()
        except (xlrd.XLRDError, ValueError, OSError) as exc:
            raise InvalidDocument('Invalid XLS workbook') from exc

def handle_attachment(filename, payload, origin, depth, ctx):
    ctx['attachment_count'] += 1
    if ctx['attachment_count'] > MAX_ATTACHMENTS:
        raise InvalidDocument('Email exceeds attachment count limit')
    if len(payload) > MAX_ATTACHMENT_BYTES:
        ctx['warnings'].append(f'{origin}: attachment too large; skipped')
        return
    ctx['total_attachment_bytes'] += len(payload)
    if ctx['total_attachment_bytes'] > MAX_TOTAL_ATTACHMENT_BYTES:
        raise InvalidDocument('Email exceeds cumulative attachment size limit')
    try:
        extract_document(payload, filename, origin, depth + 1, ctx)
    except InvalidDocument as exc:
        ctx['warnings'].append(f'{origin}: {exc}')

def eml_extract(data, origin, depth, ctx):
    try:
        message = BytesParser(policy=policy.default).parsebytes(data)
    except Exception as exc:
        raise InvalidDocument('Invalid EML message') from exc
    headers = [f'Subject: {message.get("Subject", "")}',
               f'From: {message.get("From", "")}',
               f'To: {message.get("To", "")}',
               f'Date: {message.get("Date", "")}']
    append_text(ctx, origin, '\n'.join(headers))
    for part in message.walk():
        if part.is_multipart():
            continue
        filename = part.get_filename()
        disposition = part.get_content_disposition()
        if filename or disposition == 'attachment':
            payload = part.get_payload(decode=True)
            if payload is None:
                ctx['warnings'].append(f'{origin}: attachment payload unavailable')
                continue
            name = filename or 'unnamed'
            handle_attachment(name, payload, f'{origin} / {name}', depth, ctx)
        elif part.get_content_type() == 'text/plain':
            try:
                append_text(ctx, f'{origin} / body', part.get_content())
            except Exception:
                ctx['warnings'].append(f'{origin}: could not decode text body')
        elif part.get_content_type() == 'text/html':
            # HTML-only messages need HTML-to-text sanitization; avoid storing raw markup.
            ctx['warnings'].append(f'{origin}: HTML body not extracted (text/plain preferred)')

def msg_extract(data, origin, depth, ctx):
    with tempfile.NamedTemporaryFile(suffix='.msg', delete=False) as tmp:
        tmp.write(data)
        path = tmp.name
    try:
        msg = extract_msg.Message(path)
        try:
            append_text(ctx, origin, '\n'.join([
                f'Subject: {msg.subject or ""}', f'From: {msg.sender or ""}',
                f'To: {msg.to or ""}', f'Date: {msg.date or ""}',
                str(msg.body or '')]))
            for att in msg.attachments:
                name = getattr(att, 'longFilename', None) or getattr(att, 'shortFilename', None) or 'unnamed'
                payload = getattr(att, 'data', None)
                if not isinstance(payload, bytes):
                    ctx['warnings'].append(f'{origin} / {name}: embedded MSG object not supported')
                    continue
                handle_attachment(name, payload, f'{origin} / {name}', depth, ctx)
        finally:
            msg.close()
    except (OSError, ValueError, TypeError) as exc:
        raise InvalidDocument('Invalid MSG message') from exc
    finally:
        Path(path).unlink(missing_ok=True)

def extract_document(data, filename, origin, depth, ctx):
    if depth > MAX_DEPTH:
        raise InvalidDocument('Email nesting limit exceeded')
    suffix = suffix_of(filename)
    if suffix in ('.jpg', '.jpeg', '.png'):
        image_ocr(data, suffix, origin, ctx)
    elif suffix == '.pdf':
        pdf_extract(data, origin, ctx)
    elif suffix in ('.xls', '.xlsx'):
        excel_extract(data, suffix, origin, ctx)
    elif suffix == '.eml':
        eml_extract(data, origin, depth, ctx)
    elif suffix == '.msg':
        msg_extract(data, origin, depth, ctx)

@app.post('/api/v1/process')
def process(req: ProcessRequest):
    try:
        suffix_of(req.objectKey)
        started = time.perf_counter()
        data = download(req.url)
        ctx = new_result()
        extract_document(data, req.objectKey, req.objectKey, 0, ctx)
        # Bound output to protect HPE DI response payload size.
        full_text = '\n\n'.join(f'[{source}]\n{text}' for source, text in ctx['sections'])
        if len(full_text) > MAX_TEXT_CHARS:
            full_text = full_text[:MAX_TEXT_CHARS]
            ctx['warnings'].append('Extracted text truncated at configured character limit')
        # Do not join unrelated attachment entities into one identity.
        entity_results = [extract_entities(text) for _, text in ctx['sections']]
        entities = {'first_name': None, 'last_name': None, 'ssn_last4': None, 'account_last4': None}
        if len(entity_results) == 1:
            entities.update(entity_results[0])
        elif len(entity_results) > 1:
            ctx['warnings'].append('Multiple text sections: entity fields left null to avoid mixing identities')
        score = sum(ctx['scores']) / len(ctx['scores']) if ctx['scores'] else 0.0
        ext = Path(req.objectKey).suffix.lower()
        kind = 'IMAGE' if ext in ('.jpg', '.jpeg', '.png') else ('EMAIL' if ext in ('.eml', '.msg') else ('PDF' if ext == '.pdf' else 'EXCEL'))
        return {'extracted_text': full_text, **entities, 'source_file': req.objectKey,
                'model_name': 'PaddleOCR-PP-OCRv5-fr-v3', 'language': 'fr',
                'confidence': round(score, 5),
                'inference_time_ms': round((time.perf_counter() - started) * 1000, 2),
                'text_detections': json.dumps(ctx['detections'], ensure_ascii=False),
                'document_type': kind,
                'extraction_method': 'hybrid' if ctx['ocr_used'] and kind != 'IMAGE' else ('ocr' if ctx['ocr_used'] else 'native'),
                'page_count': ctx['page_count'], 'sheet_count': ctx['sheet_count'],
                'attachment_count': ctx['attachment_count'],
                'warnings': json.dumps(ctx['warnings'], ensure_ascii=False)}
    except InvalidDocument as exc:
        raise HTTPException(422, str(exc)) from exc
    except TemporaryFailure as exc:
        raise HTTPException(503, str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:
        # Do not leak document text or presigned URLs in errors/logs.
        raise HTTPException(503, 'Document processing failure') from exc
