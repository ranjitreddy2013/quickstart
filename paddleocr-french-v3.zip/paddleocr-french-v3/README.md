# PaddleOCR French v3 — deployment runbook

This is a **reference implementation** derived from the provided v1.3 `main.py`, `entity_extractor.py` and Deployment. It has passed Python syntax compilation only. It has **not** been container-built, integration-tested, or verified against your installed HPE DI Swagger API.

## 1. Keep v1.3 unchanged

```bash
cd /root
cp -a paddleocr-french-cf paddleocr-french-cf-backup
mkdir -p paddleocr-french-v3-cf
cd paddleocr-french-v3-cf
# Extract the package into this directory (or copy its contents).
```

## 2. Verify and pin your working versions

```bash
kubectl exec -n custom-functions deployment/paddleocr-french-cdf -- \
  python -c 'import paddleocr,paddle; print("PaddleOCR",paddleocr.__version__,"PaddlePaddle",paddle.__version__)'
```

Replace the broad PaddleOCR/PaddlePaddle ranges in `requirements.txt` with these tested versions. Confirm Python wheel compatibility for the additional packages. Keep `entity_extractor.py` unchanged.

## 3. Build the v3 image

```bash
cd /root/paddleocr-french-v3-cf
docker build -t localhost/paddleocr-french-v3-cdf:v3.0 .
```

The Dockerfile pre-downloads OCR models during build. Use a build host with network access, or mirror wheels and model assets for an air-gapped environment. If Docker and Kubernetes use separate container stores, load the image into the node's containerd store (or push to a registry); `imagePullPolicy: Never` will not pull it. For example, with compatible tools and node:

```bash
docker save localhost/paddleocr-french-v3-cdf:v3.0 -o /tmp/paddleocr-v3.tar
sudo ctr -n k8s.io images import /tmp/paddleocr-v3.tar
sudo ctr -n k8s.io images ls | grep paddleocr-french-v3
```

## 4. Configure and deploy Kubernetes

Find the **hostname only** of the actual presigned S3 URL, without sharing its signature or credentials. Replace `REPLACE_WITH_EXACT_S3_HOSTNAME` in `k8s/deployment.yaml` with that hostname. Multiple approved hostnames can be comma-separated. DNS/egress controls must also restrict where the service can connect.

```bash
kubectl apply -f k8s/deployment.yaml
kubectl rollout status deployment/paddleocr-french-v3-cdf -n custom-functions
kubectl get pods,svc -n custom-functions | grep paddleocr
kubectl logs -n custom-functions deployment/paddleocr-french-v3-cdf --tail=100
```

The sample uses 2 CPU/4 GiB requested and 4 CPU/16 GiB limited, like your actual current Deployment. It adds a 2 GiB temporary volume. Ensure sufficient node capacity for both versions.

## 5. Test API with a presigned URL

```bash
kubectl port-forward -n custom-functions svc/paddleocr-french-v3-cdf 18080:8080
curl http://127.0.0.1:18080/health
curl -sS -X POST http://127.0.0.1:18080/api/v1/process \
  -H 'Content-Type: application/json' \
  --data '{"url":"<PRESIGNED_S3_URL>","objectKey":"test.pdf","bucketName":"ranjit-test-bucket","collectionName":"paddleocr-french-v3-collection"}'
```

Test: JPEG, PNG, searchable PDF, scanned PDF, EML with PDF/image/XLSX attachments, MSG with supported file attachments, XLS and XLSX. Test corrupt files, oversized inputs, deeply nested emails, and unavailable S3. **Do not put live presigned URLs in shared logs or tickets.**

## 6. Register HPE DI objects

Use your cluster's HPE DI Swagger UI. Validate endpoint paths and request field names against your installed API. Create in order:

1. `di/schema.json` as schema `paddleocr-french-v3-schema`.
2. `di/model.json` as model `paddleocr-french-v3-model` (endpoint uses the **service base URL**, matching the existing custom-function convention).
3. `di/pipeline.json` as pipeline `paddleocr-french-v3-pipeline`.
4. A new Collection `paddleocr-french-v3-collection`, linked to the v3 pipeline and an S3 source bucket. Confirm the Collection API payload in Swagger; this package does not invent it.

If v1 and v3 watch the same bucket, uploading an image may trigger both pipelines. Use a separate test bucket or controlled object prefix where supported. Do not modify the v1 pipeline.

## 7. Query Trino

```sql
SELECT object_key, document_type, extracted_text,
       attachment_count, page_count, sheet_count,
       first_name, last_name, ssn_last4, account_last4,
       warnings
FROM jdbc.di."paddleocr-french-v3-collection"
LIMIT 20;
```

Check the actual column names using `DESCRIBE jdbc.di."paddleocr-french-v3-collection";` after the Collection is created.

## Limitations and production hardening

- This reference uses filename extensions for routing; validate file signatures/MIME and scan untrusted attachments before production use.
- It extracts plain-text email bodies. HTML-only email bodies are currently reported as warnings, not converted to text.
- Embedded Outlook message attachment objects that do not expose byte payloads are reported as warnings. Ordinary `.eml`/`.msg` byte attachments recurse, with a depth limit.
- PDF pages with at least 30 extracted characters are treated as digital; mixed scanned/digital pages may need more sophisticated region detection.
- `.xlsx` uses cached formula results; formula caches may be missing. Excel row/sheet layout is flattened to text.
- Entity fields are populated only when exactly one text section is present. For multi-section documents, the fields are null and a warning is emitted to prevent merging unrelated identities. Per-section entities are not yet represented in the flat DI schema.
- Confidence is average OCR confidence for recognized lines; native text extraction yields 0.0, **not** a confidence estimate.
- Truncation at `MAX_TEXT_CHARS` and large `text_detections` payloads can exceed DI response limits. Test your DI limit and consider storing per-section results separately.
- Strict attachment count/size/depth and PDF page/cell limits are included, but compressed-file expansion, parser CPU/memory consumption, HTML sanitization, and content scanning need additional hardening.
- HTTP 503 is used for transient downloads and unexpected processing exceptions. Deterministic parser failures should be classified as HTTP 422 after testing to avoid retries.
- S3 hostname allowlisting and disabled redirects are present; enforce Kubernetes network egress restrictions, prevent proxy-based bypasses, and use a trusted TLS configuration.
- Restrict Trino/Superset access to extracted personal information. Do not log document text or credentials.
