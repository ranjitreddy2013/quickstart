import re
import unicodedata


def normalize(text):
    text = unicodedata.normalize('NFKD', text)
    text = ''.join(c for c in text if not unicodedata.combining(c))
    return text.lower().strip()


def get_value(lines, labels):
    for i, line in enumerate(lines):
        normalized = normalize(line)
        for label in labels:
            pattern = rf'^{re.escape(label)}\s*[:：]\s*(.*)$'
            if re.match(pattern, normalized):
                parts = re.split(r'[:：]', line, maxsplit=1)
                value = parts[1].strip() if len(parts) > 1 else ''
                if value:
                    return value
                if i + 1 < len(lines):
                    return lines[i + 1].strip()
    return None


def extract_entities(ocr_text):
    lines = [line.strip() for line in ocr_text.splitlines() if line.strip()]
    first_name = get_value(lines, ['prenom', 'prenoms'])
    last_name = get_value(lines, ['nom', 'nom de famille'])
    ssn = get_value(lines, ['numero de securite sociale', 'nir'])
    account = get_value(lines, ['numero de compte', 'n° de compte'])
    ssn_last4 = None
    account_last4 = None
    if ssn:
        digits = re.sub(r'\D', '', ssn)
        if len(digits) == 15:
            ssn_last4 = digits[-4:]
    if account:
        cleaned = re.sub(r'[\s-]', '', account)
        if re.fullmatch(r'[A-Za-z0-9]+', cleaned):
            account_last4 = cleaned[-4:]
    return {'first_name': first_name, 'last_name': last_name,
            'ssn_last4': ssn_last4, 'account_last4': account_last4}
