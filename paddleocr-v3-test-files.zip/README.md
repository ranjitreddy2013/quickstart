# PaddleOCR French v3 — Fichiers de test

These files contain only synthetic French-language test data.

| File | Test |
|---|---|
| test-image.png / test-image.jpeg | Existing image OCR |
| test-digital.pdf | Native PDF text extraction |
| test-scanned.pdf | OCR fallback for image-only PDF |
| test-excel.xlsx | Worksheet / cell extraction |
| test-email-with-attachments.eml | EML body + PDF/XLSX/PNG attachments |
| test-nested-email.eml | Nested email parsing (may be unsupported depending on implementation; check warnings) |

Expected synthetic entities: first_name Camille, last_name Martin, ssn_last4 2345 (for image/PDF), account_last4 0123. Note that your entity extractor may interpret the account value differently depending on format and boundaries.

**Not included:** .msg and legacy .xls; these require format-specific writers and should be tested with genuine files exported by Outlook / legacy Excel. Renaming an .eml to .msg or .xlsx to .xls does not produce a valid file.

## Upload to S3
Use your configured S3 client or the HPE X10000 UI. Upload the files to your v3 test bucket.

## Test
For each object, create a presigned GET URL and POST to /api/v1/process with url, objectKey, bucketName, collectionName. Keep presigned URLs private.

The nested email fixture is a parser edge-case test: warnings or a skipped nested part may be expected if recursive message/rfc822 handling is not implemented.
